package com.cache.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.LinkedHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.cache.advice.ErrorMessage;
import com.cache.commons.ApplicationConstant;
import com.cache.dataStore.DataStore;
import com.cache.dto.Detail;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class AgodaApplicationTests {

	@LocalServerPort
	private int port;

	TestRestTemplate restTemplate = new TestRestTemplate();
	HttpHeaders headers = new HttpHeaders();

	/**
	 * @throws Exception
	 *             positive test case to add the value in the case.
	 */
	@Test
	public void test_add_positive() throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		String payLoad = "{\"mahesh\":\"joshi\"}";
		HttpEntity<String> entity = new HttpEntity<String>(payLoad, headers);
		ResponseEntity<Boolean> response = restTemplate.exchange(createURLWithPort("/cache/add"), HttpMethod.POST,
				entity, Boolean.class);
		boolean actual = response.getBody().booleanValue();
		HttpStatus statusCode = response.getStatusCode();
		assertEquals(statusCode, HttpStatus.CREATED);

		assertTrue(actual);
	}

	/**
	 * @throws Exception
	 *             returns false for the duplicate key.
	 */
	@Test
	public void test_add_negative() throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		String payLoad = "{\"pratik\":\"joshi\"}";
		HttpEntity<String> entity = new HttpEntity<String>(payLoad, headers);
		ResponseEntity<Boolean> response = restTemplate.exchange(createURLWithPort("/cache/add"), HttpMethod.POST,
				entity, Boolean.class);
		ResponseEntity<Boolean> secondResponse = restTemplate.exchange(createURLWithPort("/cache/add"), HttpMethod.POST,
				entity, Boolean.class);
		boolean actual = secondResponse.getBody().booleanValue();
		HttpStatus statusCode = secondResponse.getStatusCode();
		assertEquals(statusCode, HttpStatus.OK);
		assertFalse(actual);
	}

	/**
	 * this method test if existing key is being deleted successfully or not
	 * 
	 */
	@Test
	public void test_remove_positive() {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		String payLoad = "{\"remove\":\"key\"}";
		HttpEntity<String> entity = new HttpEntity<String>(payLoad, headers);
		ResponseEntity<Boolean> response = restTemplate.exchange(createURLWithPort("/cache/add"), HttpMethod.POST,
				entity, Boolean.class);
		ResponseEntity<Boolean> removeResponse = restTemplate.exchange(createURLWithPort("/cache/remove/remove"),
				HttpMethod.DELETE, entity, Boolean.class);
		boolean actual = removeResponse.getBody().booleanValue();
		boolean lookupCheck = DataStore.indexMap.containsKey("remove");
		Detail detail = new Detail();
		detail.setKey("remove");
		detail.setValue("key");
		boolean cacheChek = DataStore.cache.contains(detail);
		HttpStatus statusCode = response.getStatusCode();
		assertEquals(statusCode, HttpStatus.CREATED);
		assertFalse(cacheChek);
		assertFalse(lookupCheck);
		assertTrue(actual);

	}

	@Test
	public void test_remove_negative() {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<ErrorMessage> removeResponse = restTemplate.exchange(createURLWithPort("/cache/remove/nonExist"),
				HttpMethod.DELETE, entity, ErrorMessage.class);
		ErrorMessage actual = removeResponse.getBody();
		assertEquals(ApplicationConstant.ENTITY_NOT_EXIST, actual.getMeassage().get(0).toString());
	}

	@Test
	public void test_remove_with_null() {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<ErrorMessage> removeResponse = restTemplate.exchange(createURLWithPort("/cache/remove/"),
				HttpMethod.DELETE, entity, ErrorMessage.class);
		HttpStatus actual = removeResponse.getStatusCode();
		assertEquals(HttpStatus.NOT_FOUND, actual);
	}

	@Test
	public void test_peek_positive() {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		String payLoad = "{\"peek\":\"value\"}";
		HttpEntity<String> entity = new HttpEntity<String>(payLoad, headers);
		ResponseEntity<Boolean> response = restTemplate.exchange(createURLWithPort("/cache/add"), HttpMethod.POST,
				entity, Boolean.class);
		ResponseEntity<Detail> secondResponse = restTemplate.getForEntity(createURLWithPort("/cache/peek"),
				Detail.class);
		String key = (String) secondResponse.getBody().getKey();
		String value = (String) secondResponse.getBody().getValue();
		HttpStatus statusCode = secondResponse.getStatusCode();
		assertEquals(statusCode, HttpStatus.OK);
		assertEquals(key, "peek");
		assertEquals(value, "value");
	}

	@Test
	public void test_peek_negative() {
		DataStore.cache.clear();
		ResponseEntity<Object> secondResponse = restTemplate.getForEntity(createURLWithPort("/cache/peek"),
				Object.class);
		HttpStatus statusCode = secondResponse.getStatusCode();
		assertEquals(statusCode, HttpStatus.NO_CONTENT);
	}

	/**
	 * this method will test positive scenario to fetch and delete value from
	 * the queue.
	 */
	@Test
	public void test_take_positive() {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		String payLoad = "{\"take\":\"value\"}";
		HttpEntity<String> entity = new HttpEntity<String>(payLoad, headers);
		ResponseEntity<Boolean> response = restTemplate.exchange(createURLWithPort("/cache/add"), HttpMethod.POST,
				entity, Boolean.class);
		ResponseEntity<Object> secondResponse = restTemplate.getForEntity(createURLWithPort("/cache/take"),
				Object.class);
		HttpStatus statusCode = secondResponse.getStatusCode();
		LinkedHashMap<String, Object> detail = (LinkedHashMap<String, Object>) secondResponse.getBody();
		assertEquals(statusCode, HttpStatus.OK);
		assertTrue(detail.containsValue("take"));
		assertEquals("value", detail.get("value"));
	}

	/**
	 * this method will check the blocking behaviour of the method it will not
	 * give null pointer even though for the first 1000ms cache is empty but
	 * will wait till the time producer thread insert the value in the queue and
	 * then it delete it and pass the same entity to the client as a response.
	 */
	@Test
	public void test_take_blocking() {
		DataStore.cache.clear();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		ExecutorService executorService = Executors.newFixedThreadPool(3);
		Producer producer = new Producer();
		executorService.submit(producer);
		ResponseEntity<Object> secondResponse = restTemplate.getForEntity(createURLWithPort("/cache/take"),
				Object.class);
		HttpStatus statusCode = secondResponse.getStatusCode();
		LinkedHashMap<String, Object> detail = (LinkedHashMap<String, Object>) secondResponse.getBody();
		assertEquals(statusCode, HttpStatus.OK);
		assertEquals("take", detail.get("key"));
		assertEquals("value", detail.get("value"));
		assertEquals(DataStore.cache.size(), 0);
	}

	private String createURLWithPort(String uri) {
		return "http://localhost:" + port + uri;
	}

	public class Producer implements Runnable {

		@Override
		public void run() {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
			String payLoad = "{\"take\":\"value\"}";
			HttpEntity<String> entity = new HttpEntity<String>(payLoad, headers);
			ResponseEntity<Boolean> response = restTemplate.exchange(createURLWithPort("/cache/add"), HttpMethod.POST,
					entity, Boolean.class);
		}

	}

}
