package com.cache;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author pratik
 *
 */
@SpringBootApplication
public class CacheApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(CacheApplication.class, args);
	}

}
