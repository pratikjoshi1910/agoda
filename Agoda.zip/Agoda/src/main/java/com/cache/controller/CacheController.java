package com.cache.controller;

import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cache.commons.ApplicationConstant;
import com.cache.dto.Detail;
import com.cache.exceptions.CustomException;
import com.cache.service.CacheService;

/**
 * @author pratik
 *
 */
@RestController
@RequestMapping("/cache")
public class CacheController {
	private static final Logger logger = LoggerFactory.getLogger(CacheController.class);

	@Autowired
	CacheService cacheService;

	/**
	 * @param data
	 * @return
	 * @throws CustomException
	 */
	@PostMapping("/add")
	@ResponseBody
	public ResponseEntity<Object> addCache(@RequestBody Map<String, Object> data) throws CustomException {
		Detail detail = new Detail();
		String key = data.keySet().stream().map(Optional::ofNullable).findFirst().flatMap(Function.identity())
				.orElse(null);
		detail.setKey(key);
		Object value = data.get(key);
		detail.setValue(value);
		logger.debug("Received request for the the /add endpoint with parameters" + "key ::" + detail.getKey()
				+ "value ::" + detail.getValue());
		Boolean result = cacheService.add(detail);
		if (result) {
			return new ResponseEntity<>(result, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	/**
	 * @param key
	 * @return boolean based on operation.
	 * @throws Exception
	 */
	@DeleteMapping("/remove/{key}")
	@ResponseBody
	public ResponseEntity<Boolean> removeCahe(@NotNull @PathVariable("key") String key) throws Exception {
		logger.debug("Received request for the the /remove endpoint with parameters" + "key ::" + key);
		return new ResponseEntity<>(cacheService.remove(key), HttpStatus.OK);
	}

	/**
	 * @return targeted key value object
	 * @throws Exception
	 */
	@GetMapping("/peek")
	@ResponseBody
	public ResponseEntity<Object> peekValueByKey() throws Exception {
		logger.debug("Received request for the the /peek endpoint.");
		Object detail = cacheService.peek();      
		if (null != detail) {
			return new ResponseEntity<Object>(detail, HttpStatus.OK);
		} else {
			return new ResponseEntity<Object>(ApplicationConstant.EMPTY_CACHE, HttpStatus.NO_CONTENT);
		}
	}

	/**
	 * @return targeted key value object
	 * @throws Exception
	 */
	@GetMapping("/take")
	@ResponseBody
	public ResponseEntity<Object> takeValueByKey() throws Exception {
		logger.debug("Received request for the the /take endpoint." );
		Object detail = cacheService.take();
			return new ResponseEntity<>(detail, HttpStatus.OK);
	}

}
