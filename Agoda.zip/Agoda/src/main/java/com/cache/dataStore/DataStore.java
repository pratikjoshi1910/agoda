package com.cache.dataStore;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedDeque;
import com.cache.dto.Detail;

public class  DataStore {
    
	/**
	 * this queue will act as a cache for the application
	 * it will store the data in serial manner and will provide
	 * requested elements based on the the relevant api call.
	 * 
	 */
	public static ConcurrentLinkedDeque<Detail> cache = new ConcurrentLinkedDeque<Detail>();
	public static ConcurrentHashMap<Object,Object> indexMap = new ConcurrentHashMap<>();
}
