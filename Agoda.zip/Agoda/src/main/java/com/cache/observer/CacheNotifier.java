package com.cache.observer;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

import com.cache.dataStore.DataStore;
import com.cache.dto.Detail;

/**
 * @author pratik
 * 
 *provides implementation for the cacheNotifier.
 */
public class CacheNotifier implements Notifier{

	public static volatile ConcurrentLinkedQueue<Thread> observer = null;
	public static volatile Object result;

	@Override
	public  void addObserver(Thread servent) {
		if (null == observer) {
			observer = new ConcurrentLinkedQueue<Thread>();
			observer.add(servent);
		} else {
			observer.add(servent);
		}
	}
	@Override
	public  synchronized void notifyObserver() {
		if (null!=observer && observer.size() >0) {
			result = DataStore.cache.pollLast();
			Detail detail = (Detail) result;
			DataStore.indexMap.remove(detail.getKey());
			List<Thread> intrupptedThreads = new ArrayList<Thread>();
			for (Thread thread : observer) {
				thread.interrupt();
				intrupptedThreads.add(thread);
			}
			observer.remove(intrupptedThreads);
		}
	}
}
