package com.cache.observer;

/**
 * @author pratik
 *
 */
public interface Notifier {

	
	public  void addObserver(Thread servent) ;
	
	public  void notifyObserver() ;

}
