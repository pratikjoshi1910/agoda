package com.cache.observer;

import java.util.HashMap;
import java.util.Map;

import com.cache.commons.ApplicationConstant;

/**
 * @author pratik
 * 
 *this class can be used as the factory pattern for various type of notifier.
 */
public class NotifierFactory {
	public static Notifier notifier = null;
	public static Map<String, Notifier> notifierMap = new HashMap<String, Notifier>();

	public static Notifier getObserver(String type) {
		if (null != notifierMap.get(type)) {
			return notifierMap.get(type);
		} else if (type.equals(ApplicationConstant.CACHE_MAP)) {
			notifier = new CacheNotifier();
			notifierMap.put(ApplicationConstant.CACHE_MAP, notifier);
		}
		return notifier;
	}

}
