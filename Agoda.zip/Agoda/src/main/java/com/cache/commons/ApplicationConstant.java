package com.cache.commons;

public class ApplicationConstant {

	public static final String SOMETHING_WRONG = "Something wrong happend please contact admin.";
	public static final String ENTITY_NOT_EXIST = "Entry corresponding to the given key does not exist.";
	public static final String EMPTY_CACHE = "Currently there is not data in the cache memory.";
	public static String NULL_KEY = "Key provided in a request is null.";
	public static final String CACHE_MAP = "cache";
}
