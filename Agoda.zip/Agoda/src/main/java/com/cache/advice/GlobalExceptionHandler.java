package com.cache.advice;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cache.exceptions.CustomException;

/**
 * @author pratik 
 * GlobalExceptionHandler is the common exit point for any
 *  exception occur in the system here exception is converted into the
 * responsebody and response is served to the endclient.
 */
@org.springframework.web.bind.annotation.ControllerAdvice
public class GlobalExceptionHandler {
	private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	/**
	 * @param ex
	 * @param headers
	 * @param status
	 * @param request
	 * @return ResponsEntity with errorObject
	 */
	@ExceptionHandler(Exception.class)
	protected ResponseEntity<Object> handleMethodArgumentNotValid(Exception ex) {
		logger.info("inside the method of global exception hadler for exception with message." + ex.getMessage());
		ErrorMessage errorMessage = new ErrorMessage();
		errorMessage.setMeassage(Arrays.asList(ex.getLocalizedMessage()));
		ResponseEntity<Object> entity = new ResponseEntity<Object>(errorMessage, HttpStatus.INTERNAL_SERVER_ERROR);
		return entity;
	}

	/**
	 * @param 
	 * exception of type customException
	 * @return the response with error code and message
	 */
	@ExceptionHandler(CustomException.class)
	protected ResponseEntity<Object> customExceptionHandler(CustomException exception) {
		logger.info("inside the method of global exception hadler for custom exception with message." + exception.getMessage());
		ErrorMessage errorMessage = new ErrorMessage();
		errorMessage.setCode(exception.getStatusCode().toString());
		errorMessage.setMeassage(Arrays.asList(exception.getMessage()));
		ResponseEntity<Object> entity = new ResponseEntity<Object>(errorMessage, exception.getStatusCode());
		return entity;
	}
}
