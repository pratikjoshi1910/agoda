package com.cache.advice;

import java.util.List;

/**
 * this class can act as a global error message business object
 */
public class ErrorMessage {

	private String code;

	private List<Object> meassage;

	/**
	 * @return the meassage
	 */
	public List<Object> getMeassage() {
		return meassage;
	}

	/**
	 * @param meassage the meassage to set
	 */
	public void setMeassage(List<Object> meassage) {
		this.meassage = meassage;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	
}
