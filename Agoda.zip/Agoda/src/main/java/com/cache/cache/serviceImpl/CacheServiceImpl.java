package com.cache.cache.serviceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.cache.commons.ApplicationConstant;
import com.cache.dataStore.DataStore;
import com.cache.dto.Detail;
import com.cache.exceptions.CustomException;
import com.cache.observer.CacheNotifier;
import com.cache.observer.NotifierFactory;
import com.cache.service.CacheService;

@Service("cacheService")
public class CacheServiceImpl implements CacheService {
	private static final Logger logger = LoggerFactory.getLogger(CacheService.class);

	CacheNotifier notifier = (CacheNotifier) NotifierFactory.getObserver(ApplicationConstant.CACHE_MAP);

	/*
	 * @see com.cache.service.CacheService#add(com.cache.dto.Detail) this method
	 * will check if the entry exist in index map if not then enter the value in
	 * the index map as well as in the cache queue else it will simply return
	 * false
	 */
	public Boolean add(Detail detail) throws CustomException {
		Object key = detail.getKey();
		logger.info("inside the method of add adding value with key ::" + key + "value ::" + detail.getValue());
		if (null == key) {
			throw new CustomException(ApplicationConstant.NULL_KEY, HttpStatus.BAD_REQUEST);
		}
		Object dataDetail = DataStore.indexMap.putIfAbsent(detail.getKey(), detail.getValue());
		if (null != dataDetail) {
			return false;
		} else {
			try {
				DataStore.cache.addLast(detail);
			} catch (Exception e) {
				DataStore.indexMap.remove(detail.getKey());
				throw new CustomException(ApplicationConstant.SOMETHING_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);
			}
			notifier.notifyObserver();
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cache.service.CacheService#remove(java.lang.String)
	 */
	@Override
	public Boolean remove(String key) throws CustomException {
		logger.info("inside the method of remove  with key ::" + key);

		if (null == key) {
			logger.info("method throwing custom exception due to null key");
			throw new CustomException(ApplicationConstant.NULL_KEY, HttpStatus.BAD_REQUEST);
		}
		Object result = DataStore.indexMap.get(key);
		if (null != result) {
			DataStore.indexMap.remove(key);
			try {
				Detail detail = new Detail();
				detail.setKey(key);
				DataStore.cache.remove(detail);
				return true;
			} catch (Exception e) {
				logger.info("reverting transaction because of exception in remove method" + e.getMessage());
				DataStore.indexMap.put(key, result);
				throw new CustomException(ApplicationConstant.SOMETHING_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);

			}
		} else {
			throw new CustomException(ApplicationConstant.ENTITY_NOT_EXIST, HttpStatus.BAD_REQUEST);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cache.service.CacheService#peek()
	 */
	@Override
	public Object peek() {
		logger.info("inside the peek method");
		return DataStore.cache.peekLast();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.cache.service.CacheService#take()
	 */
	@Override
	public Object take() {
		logger.info("inside the take method");
		Detail result = DataStore.cache.pollLast();
		if (null != result) {
			logger.info("removing value from queue and lookup map.");
			DataStore.indexMap.remove(result.getKey());
			return result;
		} else {
			logger.info("putting current thread in a observer queue and sleep state as the queue is empty as of now.");
			notifier.addObserver(Thread.currentThread());
			try {
				Thread.sleep(Integer.MAX_VALUE);
			} catch (InterruptedException e) {
				logger.info("thread is interrupted.");
				result = (Detail) CacheNotifier.result;
				logger.info("returning poll result " + result);

			}

		}

		return result;
	}

}