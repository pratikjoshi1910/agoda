package com.cache.service;

import com.cache.dto.Detail;
import com.cache.exceptions.CustomException;

public interface CacheService {

	public Boolean add(Detail detail) throws CustomException;

	Boolean remove(String key) throws CustomException;

	public Object peek();

	public Object take() throws InterruptedException;
}
